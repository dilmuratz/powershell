#!/bin/bash 

set -ex

echo '10.106.10.63 srv1230.' >> /etc/hosts 
echo '10.106.10.64 srv1240.' >> /etc/hosts 


export ANSIBLE_CONFIG=./ansible.cfg
export ANSIBLE_PYTHON_INTERPRETER=/usr/bin/python3
export ANSIBLE_HASHI_VAULT_TOKEN=$HASHI_VAULT_TOKEN
echo $HASHI_VAULT_TOKEN > ./.ansible_vault 

# ansible-playbook ./playbooks/callback.yml
# ansible-playbook ./playbooks/get_ssh_key.yml
ansible-playbook ./playbooks/get-secrets.yml
ansible-playbook ./playbooks/provision-ha.yml -i ./inventory.yml $ANSIBLE_ARGS -vvvv

